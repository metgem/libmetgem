"""
    Functions and constants used by other modules.
"""

MZ = 0
INTENSITY = 1